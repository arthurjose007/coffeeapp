class coffee {
  String name;
  String price;
  String imagepath;
  coffee({required this.name, required this.imagepath, required this.price});
}
