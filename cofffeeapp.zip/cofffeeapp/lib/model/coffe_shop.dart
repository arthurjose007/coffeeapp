import 'package:cofffeeapp/model/coffee.dart';
import 'package:flutter/material.dart';

class coffeeshop extends ChangeNotifier {
  //coffe for sale list
  List<coffee> _shop = [
    //black coffee
    coffee(
      name: 'Black coffee',
      imagepath: "assets/blackcoffee.png",
      price: '4.2',
    ),

    //lata
    coffee(name: 'Lata', imagepath: "assets/latte.png", price: "5.2"),

    //Ice coffee
    coffee(name: "Ice coffee", imagepath: "assets/coffee.png", price: "3.4"),
    //expresso
    coffee(name: "expresso", imagepath: "assets/cupcoffe.png", price: "4.2"),
  ];

  //user cart
  List<coffee> _userCart = [];

  //get coffee list
  List<coffee> get coffeeShop => _shop;

  //get user cart
  List<coffee> get userCart => _userCart;
  //add item cart
  void addTocart(coffee coffee) {
    _userCart.add(coffee);
    notifyListeners();
  }

  //remove it from cart
  void removeTocart(coffee coffe) {
    _userCart.remove(coffe);
    notifyListeners();
  }
}
