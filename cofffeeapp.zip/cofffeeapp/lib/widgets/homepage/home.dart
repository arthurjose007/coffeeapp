import 'package:cofffeeapp/widgets/conmponents/bottomnavbar.dart';
import 'package:cofffeeapp/widgets/const/constents.dart';
import 'package:cofffeeapp/widgets/homepage/cartpage.dart';
import 'package:cofffeeapp/widgets/homepage/shoppage.dart';
import 'package:flutter/material.dart';

class homePage extends StatefulWidget {
  homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {
  int selectedindex = 0;

  void navigatorbottombar(int index) {
    setState(() {
      selectedindex = index;
    });
  }

  List pages = <Widget>[
    shoppage(),
    cartpage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundcolor,
      bottomNavigationBar:
          Bottomnavebar(onTabbarchange: (index) => navigatorbottombar(index)),
      body: pages[selectedindex],
    );
  }
}
