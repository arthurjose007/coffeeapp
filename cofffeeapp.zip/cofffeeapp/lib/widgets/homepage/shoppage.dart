import 'package:cofffeeapp/model/coffe_shop.dart';
import 'package:cofffeeapp/model/coffee.dart';
import 'package:cofffeeapp/widgets/conmponents/coffetile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class shoppage extends StatefulWidget {
  const shoppage({super.key});

  @override
  State<shoppage> createState() => _shoppageState();
}

class _shoppageState extends State<shoppage> {
  void addtocart(coffee coffees) {
    Provider.of<coffeeshop>(context, listen: false).addTocart(coffees);
    showDialog(
        context: context,
        builder: (constext) {
          return AlertDialog(
            title: Text('sussfully to the cart added'),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    final newprovider = Provider.of<coffeeshop>(context);
    return SafeArea(
        child: Padding(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Text("How do you like your coffee"),
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: newprovider.coffeeShop.length,
              itemBuilder: (context, index) {
                coffee eatchcoffee = newprovider.coffeeShop[index];
                return coffeeTile(
                  icon: Icon(Icons.add),
                  coffees: eatchcoffee,
                  onpressed: () => addtocart(eatchcoffee),
                );
              },
            ),
          )
        ],
      ),
    ));
  }
}
