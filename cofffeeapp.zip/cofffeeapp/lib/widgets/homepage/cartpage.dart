import 'package:cofffeeapp/model/coffe_shop.dart';
import 'package:cofffeeapp/model/coffee.dart';
import 'package:cofffeeapp/widgets/conmponents/coffetile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class cartpage extends StatefulWidget {
  const cartpage({super.key});

  @override
  State<cartpage> createState() => _cartpageState();
}

class _cartpageState extends State<cartpage> {
  void delete(coffee coffees) {
    Provider.of<coffeeshop>(context, listen: false).removeTocart(coffees);
  }

  @override
  Widget build(BuildContext context) {
    final thecoffee = Provider.of<coffeeshop>(context);
    return SafeArea(
      child: Column(
        children: [
          Text('Your Cart'),
          Expanded(
              child: ListView.builder(
                  itemCount: thecoffee.userCart.length,
                  itemBuilder: (context, index) {
                    final eatchcoffe = thecoffee.userCart[index];
                    return coffeeTile(
                        coffees: eatchcoffe,
                        onpressed: () => delete(eatchcoffe),
                        icon: Icon(Icons.delete));
                  })),
          Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.grey[900]),
            child: Center(
              child: Text(
                'Pay Now',
                style: TextStyle(color: Colors.white),
              ),
            ),
          )
        ],
      ),
    );
  }
}
