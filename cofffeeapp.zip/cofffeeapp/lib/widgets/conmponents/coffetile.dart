import 'package:cofffeeapp/model/coffee.dart';
import 'package:flutter/material.dart';

class coffeeTile extends StatelessWidget {
  final coffee coffees;
  void Function()? onpressed;
  final Widget icon;
  coffeeTile(
      {super.key,
      required this.coffees,
      required this.onpressed,
      required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
      margin: const EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
          color: Colors.grey[300], borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        title: Text(coffees.name),
        subtitle: Text(coffees.price),
        leading: Image.asset(coffees.imagepath),
        trailing: IconButton(
          onPressed: onpressed,
          icon: icon,
        ),
      ),
    );
  }
}
