import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class Bottomnavebar extends StatelessWidget {
  void Function(int)? onTabbarchange;
  Bottomnavebar({super.key, required this.onTabbarchange});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(30),
      child: GNav(
          onTabChange: (value) => onTabbarchange!(value),
          mainAxisAlignment: MainAxisAlignment.center,
          tabBorderRadius: 24,
          tabActiveBorder: Border.all(color: Colors.white),
          color: Colors.grey[400],
          activeColor: Colors.grey[700],
          tabBackgroundColor: Colors.grey.shade300,
          tabs: const [
            GButton(
              icon: Icons.home,
              text: 'Shop',
            ),
            GButton(
              icon: Icons.shopping_bag,
              text: 'Shop',
            ),
          ]),
    );
  }
}
