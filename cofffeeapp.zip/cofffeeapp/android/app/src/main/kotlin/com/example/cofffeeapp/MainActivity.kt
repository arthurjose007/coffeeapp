package com.example.cofffeeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
